# Observer init
